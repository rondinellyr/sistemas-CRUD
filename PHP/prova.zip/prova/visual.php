<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo de crud</title>
</head>
<body>
    <h1>criar um registro</h1>

    <form action="criar.php" method="POST">
        <!-- o tipo 'hidden' envia o id automaticamente ao php,
            sem a necessidade de criar um campo pro usuário 
        -->
        <input type="hidden" name="id" required>

        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>
        <br>

        <label for="raca">Raca:</label>
        <input type="text" name="raca">
        <br>

        <label for="sexo">Sexo:</label>
        <input type="text" name="sexo">
        <br>

        <label for="cor">Cor:</label>
        <input type="text" name="cor">
        <br>

        <label for="nascimento">Nascimento:</label>
        <input type="date" name="nascimento">
        <br>

        <label for="peso">Peso(kg):</label>
        <input type="number" name="peso">
        <br>

        <label for="altura">Altura(cm):</label>
        <input type="number" name="altura">
        <br>

        <button type="submit">Inserir</button>
    </form>

    <h2>Registros:</h2>
    <?php include 'ler.php'; ?>

    <h2>atualizar um registro:</h2>
    <form action="atualizar.php" method="POST">
        <label for="id">ID:</label>
        <input type="number" name="id" required>
        <br>

        <label for="nome">Novo Nome:</label>
        <input type="text" name="nome" required>
        <br>

        <label for="raca">Nova Raca:</label>
        <input type="text" name="raca" required>
        <br>

        <label for="sexo">Novo Sexo:</label>
        <input type="text" name="sexo" required>
        <br>

        <label for="cor">Nova Cor:</label>
        <input type="text" name="cor" required>
        <br>

        <label for="nascimento">Novo Nascimento:</label>
        <input type="date" name="nascimento" required>
        <br>

        <label for="peso">Novo Peso:</label>
        <input type="float" name="peso" required>
        <br>

        <label for="altura">Nova Altura:</label>
        <input type="float" name="altura" required>
        <br>

        <button type="submit">Atualizar</button>
    </form>

</body>
</html>

    <h2>excluir um registro:</h2>
    <form action="deletar.php" method="POST">
        <label for="id">ID:</label>
        <input type="number" name="id" required>
        <br>

        <button type="submit">Excluir</button>
    </form>
</body>
</html>
