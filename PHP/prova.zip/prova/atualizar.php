<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $raca = $_POST['raca'];
    $sexo = $_POST['sexo'];
    $cor = $_POST['cor'];
    $nascimento = $_POST['nascimento'];
    $peso = $_POST['peso']; 
    $altura = $_POST['altura'];

    $sql = "UPDATE animais SET nome='$nome', raca='$raca', sexo='$sexo', cor='$cor', nascimento='$nascimento', peso='$peso', altura='$altura' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar registro: " . $conn->error;
    }
}

$conn->close();
?>
