<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $raca = $_POST['raca'];
    $sexo = $_POST['sexo'];
    $cor = $_POST['cor'];
    $nascimento = $_POST['nascimento'];
    $peso = $_POST['peso']; 
    $altura = $_POST['altura'];


    $sql = "INSERT INTO animais (nome, raca, sexo, cor, nascimento, peso, altura) VALUES ('$nome', '$raca','$sexo','$cor','$nascimento','$peso', $altura)";

    if ($conn->query($sql) === TRUE) {
        echo "Registro inserido com sucesso!";
    } else {
        echo "Erro ao inserir registro: " . $conn->error;
    }
}

$conn->close();
?>