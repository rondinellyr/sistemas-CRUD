<?php
include 'conexao.php';

$sql = "SELECT * FROM animais";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nome: " . $row["nome"] . " - Raca: " . $row["raca"] . " - Sexo: " . $row["sexo"] .  " - Cor: " . $row["cor"] . " - Nascimento: " . $row["nascimento"] . " - Peso: " . $row["peso"] .  " - Altura: " . $row["altura"] .   "<br>";
    }
} else {
    echo "0 resultados encontrados";
}

$conn->close();
?>
